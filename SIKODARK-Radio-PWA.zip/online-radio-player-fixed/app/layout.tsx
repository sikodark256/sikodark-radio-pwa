import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Geist, Geist_Mono } from 'next/font/google'
import './globals.css'

const geistSans = Geist({ subsets: ['latin'], variable: '--font-geist-sans' })
const geistMono = Geist_Mono({ subsets: ['latin'], variable: '--font-geist-mono' })

export const metadata: Metadata = {
  title: 'SIKODARK Radio',
  description: 'Escuchá SIKODARK Radio en directo con metadata de la canción en tiempo real.',
  generator: 'v0.app',
  applicationName: 'SIKODARK Radio',
  keywords: ['radio', 'streaming', 'musica', 'online', 'sikodark', 'pwa'],
  authors: [{ name: 'SIKODARK' }],
  appleWebApp: {
    capable: true,
    statusBarStyle: 'black-translucent',
    title: 'SIKODARK',
  },
  formatDetection: {
    telephone: false,
  },
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
  openGraph: {
    type: 'website',
    title: 'SIKODARK Radio',
    description: 'Escuchá SIKODARK Radio en directo con metadata de la canción en tiempo real.',
    siteName: 'SIKODARK Radio',
    locale: 'es_ES',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'SIKODARK Radio',
    description: 'Escuchá SIKODARK Radio en directo',
  },
}

export const viewport: Viewport = {
  colorScheme: 'dark',
  themeColor: '#1a1720',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="es" className={`${geistSans.variable} ${geistMono.variable} bg-background`}>
      <body className="font-sans antialiased">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
