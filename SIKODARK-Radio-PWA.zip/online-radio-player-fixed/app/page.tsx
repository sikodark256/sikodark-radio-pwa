import { RadioPlayer } from "@/components/radio-player"

export default function Page() {
  return (
    <main className="flex min-h-dvh flex-col items-center justify-center gap-8 px-4 py-12">
      <RadioPlayer />

      <footer className="text-center font-mono text-xs text-muted-foreground">
        sikodark radio
      </footer>
    </main>
  )
}
