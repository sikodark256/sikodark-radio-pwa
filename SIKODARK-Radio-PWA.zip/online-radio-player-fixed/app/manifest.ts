import type { MetadataRoute } from "next"

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "SIKODARK Radio",
    short_name: "SIKODARK",
    description: "Escuchá SIKODARK Radio en directo con metadata y carátula de la canción en tiempo real.",
    start_url: "/",
    display: "standalone",
    display_override: ["standalone", "minimal-ui"],
    background_color: "#1a1720",
    theme_color: "#1a1720",
    orientation: "portrait",
    scope: "/",
    lang: "es",
    dir: "ltr",
    categories: ["music", "entertainment", "radio"],
    prefer_related_applications: false,
    shortcuts: [
      {
        name: "Escuchar radio",
        short_name: "Reproducir",
        description: "Iniciar reproducción de la radio",
        url: "/",
      },
    ],
    icons: [
      {
        src: "/icon-192.png",
        sizes: "192x192",
        type: "image/png",
        purpose: "any",
      },
      {
        src: "/icon-512.png",
        sizes: "512x512",
        type: "image/png",
        purpose: "any",
      },
      {
        src: "/icon-512.png",
        sizes: "512x512",
        type: "image/png",
        purpose: "maskable",
      },
    ],
  }
}
