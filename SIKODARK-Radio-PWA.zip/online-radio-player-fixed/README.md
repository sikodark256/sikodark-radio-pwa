# 🎵 SIKODARK Radio - PWA

Aplicación Web Progresiva de radio online en streaming, construida con **Next.js 16** y lista para desplegar en **Vercel** o **GitHub Pages**.

## ✨ Características PWA

- ✅ **Instalable** como app nativa en Android, iOS y escritorio
- ✅ **Service Worker** con caché inteligente (`@ducanh2912/next-pwa`)
- ✅ **Manifest** nativo de Next.js con iconos personalizados
- ✅ **Media Session API** → Muestra info en pantalla de bloqueo del celular
- ✅ **Iconos propios** → No aparece el icono genérico de Google
- ✅ **Botón "Instalar app"** integrado en la interfaz
- ✅ **Soporte Apple** → Web app capaz en iOS
- ✅ **HTTPS obligatorio** → Vercel lo provee gratis

## 📁 Estructura de archivos PWA

```
├── app/
│   ├── manifest.ts          ← Manifiesto PWA (Next.js nativo)
│   ├── layout.tsx           ← Metadatos y viewport PWA
│   └── page.tsx
├── components/
│   └── radio-player.tsx     ← Media Session API (pantalla bloqueo)
├── public/
│   ├── icon-192.png         ← Icono PWA 192x192
│   ├── icon-512.png         ← Icono PWA 512x512
│   ├── apple-icon.png       ← Icono para iOS
│   ├── logo-radio.png       ← Logo para pantalla de bloqueo
│   └── icon.svg             ← Icono vectorial
├── next.config.mjs          ← Configuración PWA con next-pwa
└── package.json             ← Dependencia @ducanh2912/next-pwa
```

## 🚀 Instalación y ejecución

```bash
# Instalar dependencias (incluye next-pwa)
npm install

# Desarrollo local (PWA desactivada en dev)
npm run dev

# Construcción para producción (genera Service Worker)
npm run build

# Iniciar servidor de producción
npm start
```

## 📦 Subir a GitHub

```bash
# Inicializar repositorio
git init
git add .
git commit -m "SIKODARK Radio PWA lista"
git branch -M main

# Conectar con tu repositorio
git remote add origin https://github.com/TU-USUARIO/TU-REPOSITORIO.git
git push -u origin main
```

## ☁️ Desplegar en Vercel (recomendado)

1. Ve a [vercel.com](https://vercel.com)
2. Conecta tu repositorio de GitHub
3. Vercel detecta automáticamente Next.js → **sin configuración extra**
4. ¡Listo! Tu PWA estará disponible con HTTPS en `tu-proyecto.vercel.app`

## 📱 Cómo funciona la pantalla de bloqueo

El componente `radio-player.tsx` usa la **Media Session API** para:
- Mostrar **título de la canción** y **artista** en la pantalla apagada
- Mostrar **carátula del álbum** (o logo de la radio)
- Permitir **controles play/pause** desde la notificación
- Funciona en Android, iOS y navegadores modernos

## 🎨 Iconos personalizados

Tus iconos ya están configurados:
- `icon-192.png` → Icono principal de la app
- `icon-512.png` → Icono para pantallas de alta densidad y "maskable"
- `apple-icon.png` → Icono para agregar a pantalla de inicio en iOS

> 💡 **No verás el icono de Google** porque el manifiesto tiene tus iconos propios bien definidos con `purpose: "any"` y `purpose: "maskable"`.

## 🔧 Tecnologías

- **Next.js 16** (App Router)
- **TypeScript**
- **Tailwind CSS 4**
- **@ducanh2912/next-pwa** (Service Worker)
- **Media Session API** (pantalla de bloqueo)
- **shadcn/ui** + **Lucide Icons**

## 📻 Stream

URL del stream: `https://stream.zeno.fm/xdkqr4btptutv`

---

Hecho con ❤️ usando v0 + Next.js + PWA
